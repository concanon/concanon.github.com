<?php

/**
	this Factory will construct various views
*/
class ViewFactory
{
	/**
		returns a view object with class identified by $viewClassName
	*/
	public function getView($viewClassName)
	{
		// code to construct and return view goes here
	}
}
