<?php

/**
	this class represents the session associated with the current user
*/
class MySession
{
	/**
		returns the userId of the currently logged in user, or null if nobody is logged in
	*/
	public function getUserId()
	{
		// session access code goes here
	}

}
