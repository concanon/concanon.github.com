<?php

/**
	this class represents a view which displays a dashboard to a logged in user.
*/
class DashboardView
{
	/**
		initialize this view with any needed variables
	*/
	public function init($vars)
	{
		// code to initialize goes here
	}
	
	/**
		renders the view as html and returns it as a string
	*/
	public function getHtml()
	{
		// code to create html goes here
	}
}
