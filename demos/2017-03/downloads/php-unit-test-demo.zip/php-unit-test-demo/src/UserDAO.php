<?php

/**
	this Data Access Object allows user data to be obtained
*/
class UserDAO
{
	/**
		given a userId, return that user's data
	*/
	public function getUser($userId)
	{
		// database access code goes here
	}

}

