<?php

/**
	this class represents a view which displays a welcome screen to any user.
*/
class WelcomeView
{
	/**
		initialize this view with any needed variables
	*/
	public function init()
	{
		// initialization code goes here
	}
	
	/**
		renders the view and returns it as a string of html
	*/
	public function getHtml()
	{
		// code to create html goes here
	}
}
